# Image Classification Project

Handwritten Digit Recognition using scikit-learn and the MNIST dataset.

## Project Overview

This project implements image classification to recognize handwritten digits (0-9) using machine learning techniques with scikit-learn. Two models are implemented:
- **Random Forest Classifier**
- **Support Vector Machine (SVM)** with PCA dimensionality reduction

## Dataset

- **MNIST**: 70,000 grayscale images of handwritten digits (28x28 pixels)
- 60,000 training samples, 10,000 test samples
- 10 classes (digits 0-9)

## Project Structure

```
image-classification/
├── data/                          # Dataset storage
├── models/                        # Saved trained models
├── notebooks/
│   └── image_classification.ipynb # Jupyter notebook for exploration
├── src/
│   ├── train.py                   # Training script
│   └── predict.py                 # Prediction script
├── requirements.txt               # Python dependencies
└── README.md                      # Project documentation
```

## Setup Instructions

### 1. Create Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Run Training

```bash
# Train Random Forest (default)
python src/train.py --model rf

# Train SVM with PCA
python src/train.py --model svm --pca

# With hyperparameter tuning (slower)
python src/train.py --model rf --tune

# Use subset of data for faster training
python src/train.py --samples 10000
```

### 4. Make Predictions

```bash
# Single image prediction
python src/predict.py --image path/to/your/image.png

# Batch prediction on directory
python src/predict.py --dir path/to/image/folder/
```

### 5. Run Jupyter Notebook

```bash
jupyter notebook notebooks/image_classification.ipynb
```

## Results

| Model | Accuracy | Notes |
|-------|----------|-------|
| Random Forest | ~97% | Fast training, good baseline |
| SVM + PCA | ~98% | Slower but higher accuracy |

## Dependencies

- numpy
- pandas
- scikit-learn
- matplotlib
- seaborn
- pillow
- joblib
- jupyter

## Author

Image Classification Project - scikit-learn
