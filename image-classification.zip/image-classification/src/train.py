"""
Image Classification Project - Training Script
Uses scikit-learn to classify MNIST handwritten digits
"""

import os
import pickle
import argparse
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, classification_report, 
                             confusion_matrix, ConfusionMatrixDisplay)
import joblib
import warnings
warnings.filterwarnings('ignore')

# Configuration
RANDOM_STATE = 42
N_SAMPLES = 70000  # Use full dataset or subset for faster training
PCA_COMPONENTS = 100  # Reduce dimensionality for SVM


def load_data(n_samples=N_SAMPLES):
    """Load MNIST dataset from OpenML."""
    print("Loading MNIST dataset...")
    mnist = fetch_openml('mnist_784', version=1, parser='auto', as_frame=False)

    X = mnist.data.astype('float32')
    y = mnist.target.astype('int64')

    if n_samples < len(X):
        indices = np.random.choice(len(X), n_samples, replace=False)
        X, y = X[indices], y[indices]

    print(f"Dataset loaded: {X.shape[0]} samples, {X.shape[1]} features")
    return X, y


def preprocess_data(X_train, X_test, use_pca=False, n_components=PCA_COMPONENTS):
    """Scale and optionally apply PCA to reduce dimensionality."""
    print("Preprocessing data (StandardScaler)...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    if use_pca:
        print(f"Applying PCA (n_components={n_components})...")
        pca = PCA(n_components=n_components, random_state=RANDOM_STATE)
        X_train_scaled = pca.fit_transform(X_train_scaled)
        X_test_scaled = pca.transform(X_test_scaled)
        print(f"PCA explained variance ratio: {pca.explained_variance_ratio_.sum():.4f}")
        return X_train_scaled, X_test_scaled, scaler, pca

    return X_train_scaled, X_test_scaled, scaler, None


def train_svm(X_train, y_train, tune=False):
    """Train Support Vector Machine classifier."""
    print("\nTraining SVM classifier...")

    if tune:
        param_grid = {
            'C': [1, 10],
            'gamma': ['scale', 'auto'],
            'kernel': ['rbf']
        }
        svm = GridSearchCV(SVC(random_state=RANDOM_STATE), param_grid, 
                          cv=3, scoring='accuracy', n_jobs=-1, verbose=1)
        svm.fit(X_train, y_train)
        print(f"Best parameters: {svm.best_params_}")
        return svm.best_estimator_
    else:
        svm = SVC(C=10, kernel='rbf', gamma='scale', random_state=RANDOM_STATE)
        svm.fit(X_train, y_train)
        return svm


def train_random_forest(X_train, y_train, tune=False):
    """Train Random Forest classifier."""
    print("\nTraining Random Forest classifier...")

    if tune:
        param_grid = {
            'n_estimators': [100, 200],
            'max_depth': [None, 20],
            'min_samples_split': [2, 5]
        }
        rf = GridSearchCV(RandomForestClassifier(random_state=RANDOM_STATE), 
                         param_grid, cv=3, scoring='accuracy', n_jobs=-1, verbose=1)
        rf.fit(X_train, y_train)
        print(f"Best parameters: {rf.best_params_}")
        return rf.best_estimator_
    else:
        rf = RandomForestClassifier(n_estimators=200, max_depth=None, 
                                    random_state=RANDOM_STATE, n_jobs=-1)
        rf.fit(X_train, y_train)
        return rf


def evaluate_model(model, X_test, y_test, model_name, output_dir):
    """Evaluate model performance and save results."""
    print(f"\nEvaluating {model_name}...")
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.4f}")

    # Classification report
    report = classification_report(y_test, y_pred, digits=4)
    print("\nClassification Report:")
    print(report)

    # Save report
    with open(f"{output_dir}/{model_name}_report.txt", "w") as f:
        f.write(f"Model: {model_name}\n")
        f.write(f"Accuracy: {accuracy:.4f}\n\n")
        f.write(report)

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(10, 8))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=range(10))
    disp.plot(ax=ax, cmap='Blues', values_format='d')
    plt.title(f'Confusion Matrix - {model_name}')
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{model_name}_confusion_matrix.png", dpi=150)
    plt.close()

    return accuracy, report


def plot_sample_predictions(model, X_test, y_test, output_dir, n_samples=25):
    """Plot sample predictions."""
    y_pred = model.predict(X_test)

    fig, axes = plt.subplots(5, 5, figsize=(12, 12))
    axes = axes.ravel()

    for i in range(n_samples):
        idx = np.random.randint(0, len(X_test))
        img = X_test[idx].reshape(28, 28)
        axes[i].imshow(img, cmap='gray')
        color = 'green' if y_pred[idx] == y_test[idx] else 'red'
        axes[i].set_title(f'True: {y_test[idx]}\nPred: {y_pred[idx]}', color=color)
        axes[i].axis('off')

    plt.suptitle('Sample Predictions (Green=Correct, Red=Wrong)', fontsize=14)
    plt.tight_layout()
    plt.savefig(f"{output_dir}/sample_predictions.png", dpi=150)
    plt.close()


def save_model(model, scaler, pca, output_dir, model_name):
    """Save trained model and preprocessors."""
    joblib.dump(model, f"{output_dir}/{model_name}_model.pkl")
    joblib.dump(scaler, f"{output_dir}/scaler.pkl")
    if pca is not None:
        joblib.dump(pca, f"{output_dir}/pca.pkl")
    print(f"\nModel saved to {output_dir}/{model_name}_model.pkl")


def main():
    parser = argparse.ArgumentParser(description='Train image classification model')
    parser.add_argument('--model', type=str, default='rf', 
                       choices=['svm', 'rf'], help='Model type: svm or rf')
    parser.add_argument('--pca', action='store_true', 
                       help='Use PCA dimensionality reduction')
    parser.add_argument('--tune', action='store_true', 
                       help='Hyperparameter tuning with GridSearchCV')
    parser.add_argument('--samples', type=int, default=70000, 
                       help='Number of samples to use')
    args = parser.parse_args()

    # Create output directories
    os.makedirs("models", exist_ok=True)
    os.makedirs("results", exist_ok=True)

    # Load data
    X, y = load_data(n_samples=args.samples)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )
    print(f"Train set: {X_train.shape[0]} samples")
    print(f"Test set: {X_test.shape[0]} samples")

    # Preprocess
    X_train_proc, X_test_proc, scaler, pca = preprocess_data(
        X_train, X_test, use_pca=args.pca, n_components=PCA_COMPONENTS
    )

    # Train model
    if args.model == 'svm':
        model = train_svm(X_train_proc, y_train, tune=args.tune)
        model_name = "SVM"
    else:
        model = train_random_forest(X_train_proc, y_train, tune=args.tune)
        model_name = "RandomForest"

    if args.pca:
        model_name += "_PCA"

    # Evaluate
    accuracy, report = evaluate_model(model, X_test_proc, y_test, model_name, "results")

    # Plot predictions
    plot_sample_predictions(model, X_test, y_test, "results")

    # Save model
    save_model(model, scaler, pca, "models", model_name)

    print("\n" + "="*50)
    print("Training complete!")
    print(f"Model: {model_name}")
    print(f"Test Accuracy: {accuracy:.4f}")
    print("="*50)


if __name__ == "__main__":
    main()
