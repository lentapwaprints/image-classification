"""
Generate sample test images from MNIST for demonstration
"""

import os
import numpy as np
from PIL import Image
from sklearn.datasets import fetch_openml

# Create test images directory
os.makedirs("data/test_images", exist_ok=True)

# Load MNIST
mnist = fetch_openml('mnist_784', version=1, parser='auto', as_frame=False)
X = mnist.data.astype('float32')
y = mnist.target.astype('int64')

# Save one sample of each digit
for digit in range(10):
    idx = np.where(y == digit)[0][0]
    img = X[idx].reshape(28, 28)
    pil_img = Image.fromarray(img.astype(np.uint8))
    pil_img.save(f"data/test_images/digit_{digit}.png")
    print(f"Saved: data/test_images/digit_{digit}.png")

print("\nSample test images generated!")
