"""
Image Classification Project - Prediction Script
Load a trained model and make predictions on new images
"""

import os
import argparse
import numpy as np
from PIL import Image
import joblib
import matplotlib.pyplot as plt


def load_image(image_path):
    """Load and preprocess a single image for prediction."""
    img = Image.open(image_path).convert('L')  # Convert to grayscale
    img = img.resize((28, 28))  # Resize to MNIST dimensions
    img_array = np.array(img, dtype='float32')

    # Invert colors if background is white (MNIST has black background)
    if np.mean(img_array) > 127:
        img_array = 255 - img_array

    img_array = img_array.flatten().reshape(1, -1)
    return img_array


def predict_single(image_path, model_path="models/RandomForest_model.pkl", 
                   scaler_path="models/scaler.pkl", pca_path=None):
    """Predict digit from a single image file."""
    print(f"Loading image: {image_path}")
    img = load_image(image_path)

    # Load preprocessor and model
    scaler = joblib.load(scaler_path)
    model = joblib.load(model_path)

    img_scaled = scaler.transform(img)

    # Apply PCA if used during training
    if pca_path and os.path.exists(pca_path):
        pca = joblib.load(pca_path)
        img_scaled = pca.transform(img_scaled)

    # Predict
    prediction = model.predict(img_scaled)[0]
    probabilities = None

    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(img_scaled)[0]

    print(f"\nPredicted digit: {prediction}")

    if probabilities is not None:
        print("\nClass probabilities:")
        for i, prob in enumerate(probabilities):
            print(f"  Digit {i}: {prob:.4f}")

    # Display image with prediction
    plt.figure(figsize=(4, 4))
    plt.imshow(img.reshape(28, 28), cmap='gray')
    plt.title(f'Predicted: {prediction}', fontsize=16)
    plt.axis('off')
    plt.tight_layout()
    plt.show()

    return prediction, probabilities


def predict_batch(image_dir, model_path="models/RandomForest_model.pkl",
                  scaler_path="models/scaler.pkl", pca_path=None):
    """Predict digits from all images in a directory."""
    scaler = joblib.load(scaler_path)
    model = joblib.load(model_path)

    if pca_path and os.path.exists(pca_path):
        pca = joblib.load(pca_path)
    else:
        pca = None

    results = []
    image_files = [f for f in os.listdir(image_dir) 
                   if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]

    print(f"Found {len(image_files)} images in {image_dir}")

    for img_file in sorted(image_files):
        img_path = os.path.join(image_dir, img_file)
        img = load_image(img_path)
        img_scaled = scaler.transform(img)

        if pca is not None:
            img_scaled = pca.transform(img_scaled)

        prediction = model.predict(img_scaled)[0]
        results.append((img_file, prediction))
        print(f"  {img_file} -> Predicted: {prediction}")

    return results


def main():
    parser = argparse.ArgumentParser(description='Make predictions with trained model')
    parser.add_argument('--image', type=str, help='Path to single image file')
    parser.add_argument('--dir', type=str, help='Directory containing images for batch prediction')
    parser.add_argument('--model', type=str, default='models/RandomForest_model.pkl',
                       help='Path to trained model')
    parser.add_argument('--scaler', type=str, default='models/scaler.pkl',
                       help='Path to scaler')
    parser.add_argument('--pca', type=str, default=None,
                       help='Path to PCA transformer (if used)')
    args = parser.parse_args()

    if args.image:
        predict_single(args.image, args.model, args.scaler, args.pca)
    elif args.dir:
        predict_batch(args.dir, args.model, args.scaler, args.pca)
    else:
        print("Please provide either --image or --dir argument")


if __name__ == "__main__":
    main()
